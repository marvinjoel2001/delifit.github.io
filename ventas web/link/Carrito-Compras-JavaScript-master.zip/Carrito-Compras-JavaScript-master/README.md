# Carrito-Compras-JavaScript
 Carrito de compras con JavaScript y LocalStorage
 
 Parte 1: https://youtu.be/JINHNhFD-kA
 
 Parte 2: https://youtu.be/H2dykaYqyN8
 
 Parte 3: https://youtu.be/M0OJF_YoqeE
 
 Parte 4: https://youtu.be/eNotNeU3H6U
